from django.contrib import admin
from .models import Vehicule

# Register your models here.
admin.site.register(Vehicule)